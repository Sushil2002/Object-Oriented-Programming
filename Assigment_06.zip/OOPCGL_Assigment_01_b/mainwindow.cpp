
//Bresenham‘s circle drawing algorithm.

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>
#include <QMessageBox>
#include <QTime>

//Initialization of display screen
QImage img(600 , 600, QImage::Format_RGB888); //for white color(250 is for white and 0 is for black)
QRgb rgb(qRgb(255, 255, 255));

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void delay(int millisecondsTowait){
    QTime dieTime=QTime::currentTime().addMSecs(millisecondsTowait);
    while(QTime::currentTime()<dieTime){
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
    }
}
void MainWindow::on_pushButton_clicked()
{
    assignment();
}

void MainWindow::assignment()
{
    // Taking input of diagonal coordinates from the user
    QMessageBox message, message2,message3,msg3;

    if (ui->textEdit->toPlainText().isEmpty() || ui->textEdit_2->toPlainText().isEmpty() || ui->textEdit_3->toPlainText().isEmpty() || ui->textEdit_4->toPlainText().isEmpty()) {
        message.information(0,"Error","Enter value in all the boxes");
    }

//    else if(ui->textEdit->toPlainText().isSimpleText() &&  ui->textEdit_2->toPlainText().isSimpleText() &&  ui->textEdit_3->toPlainText().isSimpleText()){
//        message2.information(0,"Error","Enter Numerical values only");
//    }

    else if(ui->textEdit->toPlainText().toInt() > 600 || ui->textEdit_2->toPlainText().toInt() > 600 || ui->textEdit_3->toPlainText().toInt() > 600 || ui->textEdit_4->toPlainText().toInt() > 600){
        message3.information(0,"Error","The entered value is out of bounds");
    }
    else if(ui->textEdit->toPlainText().toInt() &&ui->textEdit_2->toPlainText().toInt() && ui->textEdit_3->toPlainText().toInt() && ui->textEdit_4->toPlainText().toInt())
    {
        int x1 = ui->textEdit->toPlainText().toInt();
        int y1 = ui->textEdit_2->toPlainText().toInt();
        int x2 = ui->textEdit_3->toPlainText().toInt();
        int y2 = ui->textEdit_4->toPlainText().toInt();

    // Calculating the center of the inside circle
        int xC = (x1 + x2)/2;
        int yC = (y1 + y2)/2;

    // Drawing the outside quadrilateral using DDA line drawing Algorithm function
        DDA_Line(x1,y1,x2,y1);
        DDA_Line(x1,y1,x1,y2);
        DDA_Line(x1,y2,x2,y2);
        DDA_Line(x2,y1,x2,y2);

    // Drawing the inside quadrilateral using DDA line drawing Algorithm function
        DDA_Line(xC,y1,x1,yC);
        DDA_Line(x1,yC,xC,y2);
        DDA_Line(xC,y2,x2,yC);
        DDA_Line(x2,yC,xC,y1);


    // Calculating radius of circle
        int xi = (x1-xC)/2;
        int yi = (y1-yC)/2;
        int xsq = xi*xi;
        int ysq = yi*yi;
        int rad = sqrt((xsq) + (ysq));

    //Drawing circle using Bressemham Circle Drawing Algorithm function
        bresenham_circle(xC,yC,rad);

    }
    else{
        msg3.information(0,"Error","Enter the Numberic Vaule!");  //other than intger won't work
    }
}
// Implementation of Bressemham Circle Drawing Algorithm
void MainWindow::bresenham_circle(int xCenter, int yCenter, int radius)
{
    //in this method next pixel selected is that one who is at least distance
    int x = 0;
    int y = radius;
    int d = 3 - (2*radius); //Initial dicision parameter

    //Algorithm
    while (x <= y) {

        if(d > 0)
        {
            d = d + 4 * (x-y) + 10;//next decition paratmetr
            y--;
        }
        else {
            d = d + ( 4 * x) + 6;//next decition paratmetr
        }
        x++;
        img.setPixel(xCenter + x, yCenter + y , rgb);   //octet-1
        img.setPixel(xCenter - x, yCenter + y , rgb);   //octet-2
        img.setPixel(xCenter + x, yCenter - y , rgb);   //octet-3
        img.setPixel(xCenter - x, yCenter - y , rgb);   //octet-4
        img.setPixel(xCenter + y, yCenter + x , rgb);   //octet-5
        img.setPixel(xCenter + y, yCenter - x , rgb);   //octet-6
        img.setPixel(xCenter - y, yCenter + x , rgb);   //octet-7
        img.setPixel(xCenter - y, yCenter - x , rgb);   //octet-8
    }

    ui->label->setPixmap(QPixmap::fromImage(img));
    ui->label->show();
}

// Implementation of DDA line drawing Algorithm
void MainWindow::DDA_Line(float x1, float y1, float x2, float y2)
{
    float dx = (x2-x1);
    float dy = (y2-y1);   //   m(slope)=dy/dx
    float step = 0;
    if (abs(dx) >= abs(dy)){   //absoulute vaule
        step = abs(dx);
    }else {
        step = abs(dy);
    }

     dx=dx/step;
     dy=dy/step;
     float x=x1,y=y1;
     int i = 1;

     while (i <= step) {
         img.setPixel(x,y,rgb);
         x += dx;
         y += dy;
         i++;
     }
     ui->label->setPixmap(QPixmap::fromImage(img));
}


// Colour selector button
void MainWindow::on_pushButton_2_clicked()
{
    QRgb color (QColorDialog::getColor().rgb());
    rgb = color;
}


// Clear Screen buttton
void MainWindow::on_pushButton_3_clicked()
{
    for (int x = 0; x < 600; ++x)
    {
    for (int y = 0; y < 600; ++y)
     {
       img.setPixel(x, y, qRgb(0, 0, 0));
     }
   }
  ui->label->setPixmap(QPixmap::fromImage(img));
}
