#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>
#include <QMessageBox>
#include <math.h>
#include <string.h>
#include <QTime>
#define height 800
#define width 800
// define a class write a dda function make other class fill this class will inherit class line dda function will call in the fill algorithm
using namespace std;
int ver,a[100],b[100],i,y,xi[100],j,temp,k; // variables used in scan line algorithm
float slope[100],dx,dy;

QImage img(height, width, QImage::Format_RGB888); // this the image
QRgb rgb(qRgb(255, 255, 255)); // this is the color of the line
void delay(int millisecondsTowait){      //code for delay
    QTime dieTime=QTime::currentTime().addMSecs(millisecondsTowait);
    while(QTime::currentTime()<dieTime){
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
    }
}
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    for (int x = 0; x < height; ++x)
        {
            for (int y = 0; y < width; ++y)
            {
                img.setPixel(x, y, qRgb(0, 0, 0));
            }
        }
     ui->label->setPixmap(QPixmap::fromImage(img));
     ver = 0;
}

MainWindow::~MainWindow()
{
    delete ui;
}


//seed fill algorihtm->1.boundry fill 2.flood fill
void MainWindow::on_pushButton_clicked()    //for Plot
{
    // Algorithm Bresenham Line:
    QMessageBox m1,m2,m3;
    if(ui->textEdit->toPlainText().isEmpty() || ui->textEdit_2->toPlainText().isEmpty() || ui->textEdit_3->toPlainText().isEmpty() || ui->textEdit_4->toPlainText().isEmpty()){
        m1.information(0,"Alert", "Fields cannot be empty");
    }
    if(ui->textEdit->toPlainText().toInt() >= 500  || ui->textEdit_2->toPlainText().toInt() >= 500 || ui->textEdit_3->toPlainText().toInt() >= 500 || ui->textEdit_4->toPlainText().toInt() >= 500)
    {
         m3.information(0,"Alert", "Enter range values!!!!");

    }
    if(ui->textEdit->toPlainText().toInt() >= 0 || ui->textEdit_2->toPlainText().toInt() >= 0 || ui->textEdit_3->toPlainText().toInt() >= 0 || ui->textEdit_4->toPlainText().toInt() >= 0)
    {
        int x1 = ui->textEdit->toPlainText().toInt();
        int y1 = ui->textEdit_2->toPlainText().toInt();
        int x2 = ui->textEdit_3->toPlainText().toInt();
        int y2 = ui->textEdit_4->toPlainText().toInt();

        a[ver] = x2;                // set the value of vertex(x) in the array
        b[ver] = y2;                // set the vlaue of vertex(y) in the array
        ver++;                      // change the number of vertex by 1

        DDALine(x1,y1,x2,y2,ui);    // Here vertex acts number of elements that can be stored in array


    }
    else
    {
       m2.information(0,"Error", "Enter Numeric values only!!");
    }
}


void MainWindow::on_pushButton_4_clicked()    //scan fill
{
    a[ver] = a[0];
    b[ver] = b[0];
                 // set the slope array for all the vertices
                for(i=0;i<ver;i++)
                {
                    dy = b[i+1] - b[i];
                    dx = a[i+1] - a[i];
                    if(dy == 0.0)
                    {
                        slope[i] = 1.0;
                    }
                    else if(dx == 0.0)
                    {
                        slope[i] = 0.0;
                    }
                    else if((dy != 0.0) && (dx != 0.0))
                    {
                        slope[i] = dx / dy;
                    }
                }
                for(int y=0;y<height;y++)
                {
                    k = 0;

                    // code to generate the scan line table
                    for(i=0;i<ver;i++)
                    {
                        if(((b[i]<=y) && (b[i+1]>y)) || ((b[i]>y) && (b[i+1]<=y)))
                        {
                            xi[k] = int(a[i] + (slope[i]*(y-b[i])));
                            k++;
                        }
                    }
                    //bubble sort
                    //to arrange the x coordinate in ascending order
                    for(j=0;j<k-1;j++)
                    {
                        for(i=0;i<k-j-1;i++)
                        {
                            if(xi[i]>xi[i+1])
                            {
                                temp = xi[i];
                                xi[i] = xi[i+1];
                                xi[i+1] = temp;
                            }
                        }
                    }

                    // code for printing the final line
                    for(i=0;i<k;i+=2)
                    {
                        DDALine(xi[i],y,xi[i+1]+1,y,ui);
                        delay(100);
                    }
                }

}
void MainWindow::on_pushButton_2_clicked()  //change colour
{
    QRgb color(QColorDialog::getColor().rgb());
        rgb = color;
}

//h
void MainWindow::on_pushButton_3_clicked()   //for clear
{
    for (int x = 0; x < height; ++x)
            {
                for (int y = 0; y < width; ++y)
                {
                    img.setPixel(x, y, qRgb(0, 0, 0));
                }
            }
         ver = 0;
         ui->textEdit->clear();
         ui->textEdit_2->clear();
         ui->textEdit_3->clear();
         ui->textEdit_4->clear();
         ui->label_5->setPixmap(QPixmap::fromImage(img));
}

void d1::DDALine(int x1, int y1, int x2, int y2,Ui::MainWindow *ui){ // This is line drawing algorithm


            float dx,dy,step,x,y;
            dx=x2-x1;
            dy=y2-y1;
            if(abs(dx)>=abs(dy))
            {
                step=abs(dx);
            }
            else {
                step=abs(dy);
            }
            dx=dx/step;
            dy=dy/step;
            int i=0;
            x=x1;
            y=y1;
            //img.setPixel(x,y,qRgb(225,0,0));
            while(i<step)
            {
                x=x+dx;
                y=y+dy;
                img.setPixel(x,y,rgb);
                i++;
            }
         ui->label_5->setPixmap(QPixmap::fromImage(img));

}




