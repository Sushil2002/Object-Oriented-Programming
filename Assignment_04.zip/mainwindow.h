#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
//MULTILEVEL INHERITANCE
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE
class base{
public:
    friend class MainWindow;
};
class d1:public base{
public:
    void DDALine(int,int,int,int,Ui::MainWindow *);
};

class MainWindow : public QMainWindow,public d1//,public d2
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private slots:
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_clicked();
public:
    Ui::MainWindow *ui;
    friend class base;
    friend class d1;
    friend class d2;
};
#endif // MAINWINDOW_H b
